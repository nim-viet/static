This directory contains tests that require networking and cannot be run in CI.

The tests can be run manually during development using:
```nim
./koch tests cat untestable/network/stdlib
```

The directory structure mimics tests/
