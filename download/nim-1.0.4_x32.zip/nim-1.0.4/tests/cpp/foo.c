
char* myFunc() {
  return "Hello world";
}
