sfml-nimrod
===========

Nimrod binding of SFML 2.0

This is only tested for Linux at the moment

### What is needed for Windows / OS X?

* The library names need filling in
* TWindowHandle is handled differently on those platforms

I believe that is it
